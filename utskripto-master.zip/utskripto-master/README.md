# utskripto

1. Radiyya Dwisaputra (13515023)
2. Rahmad Yesa Surya (13515088)

Untuk menjalankan program :
```sh
$ python3 App.py
```
